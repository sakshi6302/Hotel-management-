import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import AdminDashboard from './components/Dashboard/AdminDashboard';
import HRDashboard from './components/Dashboard/HRDashboard';
import EmployeeDashboard from './components/Dashboard/EmployeeDashboard';

export default function AppRoutes() {
 return (
  <BrowserRouter>
   <Routes>
    <Route path='/login' element={<Login />} />
    <Route path='/register' element={<Register />} />
    <Route path='/admin-dashboard' element={<AdminDashboard />} />
    <Route path='/hr-dashboard' element={<HRDashboard />} />
    <Route path='/employee-dashboard' element={<EmployeeDashboard />} />
   </Routes>
  </BrowserRouter>
 );
}