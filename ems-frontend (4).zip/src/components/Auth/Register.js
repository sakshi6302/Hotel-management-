import React, { useState } from 'react';
import api from '../../services/api';
export default function Register() {
 const [username, setUsername] = useState('');
 const [password, setPassword] = useState('');
 const [role, setRole] = useState('EMPLOYEE');
 const register = async (e) => {
  e.preventDefault();
  try {
   await api.post('/auth/register', { username, password, role });
   alert('Registered successfully');
  } catch (err) {
   alert('Registration failed');
  }
 };
 return (<form onSubmit={register}><input value={username} onChange={e => setUsername(e.target.value)} placeholder='Username' /><input type='password' value={password} onChange={e => setPassword(e.target.value)} placeholder='Password' /><select value={role} onChange={e => setRole(e.target.value)}><option value='EMPLOYEE'>Employee</option><option value='HR'>HR</option></select><button type='submit'>Register</button></form>);
}