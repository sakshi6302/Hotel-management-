# EMS Frontend
React-based frontend for Employee Management System