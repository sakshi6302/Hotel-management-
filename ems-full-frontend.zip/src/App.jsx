import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import EmployeeForm from "./pages/EmployeeForm";
import EmployeeList from "./pages/EmployeeList";
import EmployeeProfile from "./pages/EmployeeProfile";
import { ToastContainer } from "react-toastify";

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/employees" element={<EmployeeList />} />
      <Route path="/employee/profile" element={<EmployeeProfile />} />
      <Route path="/employee/create" element={<EmployeeForm />} />
      <Route path="/employee/edit/:id" element={<EmployeeForm />} />
    </Routes>
    <ToastContainer />
  </BrowserRouter>
);

export default App;
