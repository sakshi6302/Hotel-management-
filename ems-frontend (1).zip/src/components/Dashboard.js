
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const [role, setRole] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const storedRole = localStorage.getItem('role');
    if (!storedRole) {
      navigate('/');
    } else {
      setRole(storedRole);
    }
  }, [navigate]);

  return (
    <div>
      <h1>Welcome to the EMS Dashboard</h1>
      {role === 'ADMIN' && <p>Admin access: You can create, update, delete employees.</p>}
      {role === 'HR' && <p>HR access: You can view all employees.</p>}
      {role === 'EMPLOYEE' && <p>Employee access: You can view your profile.</p>}
    </div>
  );
};

export default Dashboard;
