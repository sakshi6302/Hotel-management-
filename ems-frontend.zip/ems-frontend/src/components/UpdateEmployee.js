import React, { useEffect, useState } from 'react';import axios from 'axios';import { useParams, useNavigate } from 'react-router-dom';

const UpdateEmployee = () => {
  const [employee, setEmployee] = useState({name:'',email:'',phone:'',department:'',reportingManager:''});
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchEmployee = async () => {
      try {
        const res = await axios.get(`/employees/${id}`);
        setEmployee(res.data);
      } catch {
        alert('Failed to fetch employee data');
      }
    };
    fetchEmployee();
  }, [id]);

  const handleChange = (e) => {
    setEmployee(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`/employees/${id}`, employee);
      alert('Employee updated successfully');
      navigate('/employees');
    } catch {
      alert('Failed to update employee');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Update Employee</h2>
      <input type="text" name="name" value={employee.name} onChange={handleChange} required />
      <input type="email" name="email" value={employee.email} onChange={handleChange} required />
      <input type="text" name="phone" value={employee.phone} onChange={handleChange} required />
      <input type="text" name="department" value={employee.department} onChange={handleChange} required />
      <input type="text" name="reportingManager" value={employee.reportingManager} onChange={handleChange} required />
      <button type="submit">Update</button>
    </form>
  );
};

export default UpdateEmployee;