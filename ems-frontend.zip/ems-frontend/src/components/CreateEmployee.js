import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const CreateEmployee = () => {
  const [employee, setEmployee] = useState({name:'',email:'',phone:'',department:'',reportingManager:''});
  const navigate = useNavigate();

  const handleChange = (e) => {
    setEmployee(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/employees/create', employee);
      alert('Employee created successfully');
      navigate('/employees');
    } catch (err) {
      alert('Failed to create employee. Only Admins can do this.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create New Employee</h2>
      <input type="text" name="name" placeholder="Name" onChange={handleChange} required />
      <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
      <input type="text" name="phone" placeholder="Phone" onChange={handleChange} required />
      <input type="text" name="department" placeholder="Department" onChange={handleChange} required />
      <input type="text" name="reportingManager" placeholder="Reporting Manager" onChange={handleChange} required />
      <button type="submit">Create</button>
    </form>
  );
};

export default CreateEmployee;