import React from 'react';
import { Link } from 'react-router-dom';

const Dashboard = ({ role }) => {
  return (
    <div>
      <h2>Welcome to the EMS Dashboard</h2>
      <p>Your role: <strong>{role}</strong></p>
      {role === 'ADMIN' && (
        <div>
          <Link to="/create"><button>Create Employee</button></Link>
          <Link to="/employees"><button>View All Employees</button></Link>
        </div>
      )}
      {role === 'HR' && (
        <div>
          <Link to="/employees"><button>View All Employees</button></Link>
        </div>
      )}
      {role === 'EMPLOYEE' && (
        <div>
          <Link to="/profile"><button>View My Profile</button></Link>
        </div>
      )}
    </div>
  );
};

export default Dashboard;