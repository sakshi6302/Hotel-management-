import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Profile = () => {
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get('/employees/employee/profile');
        setProfile(res.data[0]); // assuming the response is a list with one profile
      } catch (err) {
        alert('Failed to fetch profile');
      }
    };
    fetchProfile();
  }, []);

  if (!profile) return <p>Loading profile...</p>;

  return (
    <div>
      <h2>My Profile</h2>
      <p><strong>Name:</strong> {profile.name}</p>
      <p><strong>Email:</strong> {profile.email}</p>
      <p><strong>Phone:</strong> {profile.phone}</p>
      <p><strong>Department:</strong> {profile.department}</p>
      <p><strong>Reporting Manager:</strong> {profile.reportingManager}</p>
    </div>
  );
};

export default Profile;