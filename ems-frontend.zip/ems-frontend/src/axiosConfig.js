import axios from 'axios';

axios.defaults.baseURL = 'http://localhost:8082'; // backend running on port 8082
axios.defaults.headers.post['Content-Type'] = 'application/json';