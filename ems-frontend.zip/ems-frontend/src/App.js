import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import Profile from './components/Profile';
import EmployeeList from './components/EmployeeList';
import CreateEmployee from './components/CreateEmployee';
import UpdateEmployee from './components/UpdateEmployee';
import axios from 'axios';

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [role, setRole] = useState(localStorage.getItem('role'));

  useEffect(() => {
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    } else {
      delete axios.defaults.headers.common['Authorization'];
    }
  }, [token]);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/login" element={<Login setToken={setToken} setRole={setRole} />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={token ? <Dashboard role={role} /> : <Navigate to="/login" />} />
        <Route path="/profile" element={role === 'EMPLOYEE' ? <Profile /> : <Navigate to="/dashboard" />} />
        <Route path="/employees" element={(role === 'ADMIN' || role === 'HR') ? <EmployeeList /> : <Navigate to="/dashboard" />} />
        <Route path="/create" element={role === 'ADMIN' ? <CreateEmployee /> : <Navigate to="/dashboard" />} />
        <Route path="/update/:id" element={role === 'ADMIN' ? <UpdateEmployee /> : <Navigate to="/dashboard" />} />
      </Routes>
    </Router>
  );
}

export default App;