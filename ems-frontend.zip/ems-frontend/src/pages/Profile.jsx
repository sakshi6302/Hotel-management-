import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const Profile = () => {
  const [profile, setProfile] = useState([]);
  const { auth } = useContext(AuthContext);

  useEffect(() => {
    const fetchProfile = async () => {
      const res = await axios.get('http://localhost:8080/employees/employee/profile', {
        headers: { Authorization: `Bearer ${auth.token}` },
      });
      setProfile(res.data);
    };
    fetchProfile();
  }, [auth.token]);

  return (
    <div>
      <h2>My Profile</h2>
      <ul>
        {profile.map(emp => (
          <li key={emp.id}>{emp.name} - {emp.department}</li>
        ))}
      </ul>
    </div>
  );
};

export default Profile;