import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const { auth, logout } = useContext(AuthContext);

  return (
    <div>
      <h2>Welcome {auth.username}</h2>
      <p>Role: {auth.role}</p>

      {auth.role === 'ADMIN' && <Link to="/create">Add Employee</Link>}
      {(auth.role === 'ADMIN' || auth.role === 'HR') && <Link to="/employees">View All Employees</Link>}
      {auth.role === 'EMPLOYEE' && <Link to="/profile">View My Profile</Link>}

      <button onClick={logout}>Logout</button>
    </div>
  );
};

export default Dashboard;