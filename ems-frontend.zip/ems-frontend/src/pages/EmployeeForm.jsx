import React, { useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const EmployeeForm = () => {
  const [employee, setEmployee] = useState({ name: '', department: '', email: '', phone: '', reportingManager: '' });
  const { auth } = useContext(AuthContext);

  const handleChange = (e) => {
    setEmployee({ ...employee, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:8080/employees/create', employee, {
      headers: { Authorization: `Bearer ${auth.token}` },
    });
    alert('Employee added!');
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add Employee</h2>
      <input name="name" onChange={handleChange} placeholder="Name" required />
      <input name="department" onChange={handleChange} placeholder="Department" required />
      <input name="email" onChange={handleChange} placeholder="Email" required />
      <input name="phone" onChange={handleChange} placeholder="Phone" required />
      <input name="reportingManager" onChange={handleChange} placeholder="Reporting Manager" />
      <button type="submit">Create</button>
    </form>
  );
};

export default EmployeeForm;