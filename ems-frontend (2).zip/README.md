# EMS Frontend
This is the React frontend for the Employee Management System.