import React from "react";
const Dashboard = () => <div>Dashboard Page</div>;
export default Dashboard;
