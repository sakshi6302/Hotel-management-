
import React, { useState } from 'react';
import { register } from '../services/AuthService';

const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('EMPLOYEE');

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const res = await register(username, password, role);
      alert(res);
    } catch (err) {
      alert('Registration failed');
    }
  };

  return (
    <div>
      <h2>Register</h2>
      <form onSubmit={handleRegister}>
        <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" />
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
        <select value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="EMPLOYEE">EMPLOYEE</option>
          <option value="HR">HR</option>
        </select>
        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default Register;
