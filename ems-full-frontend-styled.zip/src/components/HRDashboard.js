
import React, { useEffect, useState } from 'react';
import { getAllEmployees } from '../services/EmployeeService';

const HRDashboard = () => {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    const fetch = async () => {
      const res = await getAllEmployees();
      setEmployees(res.data);
    };
    fetch();
  }, []);

  return (
    <div>
      <h2>HR Dashboard</h2>
      <ul>
        {employees.map(emp => (
          <li key={emp.id}>{emp.name} - {emp.department} - {emp.email}</li>
        ))}
      </ul>
    </div>
  );
};

export default HRDashboard;
