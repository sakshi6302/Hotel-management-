
import React, { useEffect, useState } from 'react';
import { getEmployeeProfile } from '../services/EmployeeService';

const EmployeeDashboard = () => {
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    const fetch = async () => {
      const res = await getEmployeeProfile();
      setProfile(res.data[0]);
    };
    fetch();
  }, []);

  return (
    <div>
      <h2>Employee Profile</h2>
      {profile && (
        <div>
          <p>Name: {profile.name}</p>
          <p>Department: {profile.department}</p>
          <p>Email: {profile.email}</p>
          <p>Phone: {profile.phone}</p>
          <p>Reporting Manager: {profile.reportingManager}</p>
        </div>
      )}
    </div>
  );
};

export default EmployeeDashboard;
