
import React, { useEffect, useState } from 'react';
import { getAllEmployees, createEmployee, updateEmployee, deleteEmployee } from '../services/EmployeeService';

const AdminDashboard = () => {
  const [employees, setEmployees] = useState([]);
  const [newEmployee, setNewEmployee] = useState({ name: '', department: '', email: '', phone: '', reportingManager: '' });

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    const res = await getAllEmployees();
    setEmployees(res.data);
  };

  const handleCreate = async () => {
    await createEmployee(newEmployee);
    fetchEmployees();
  };

  const handleDelete = async (id) => {
    await deleteEmployee(id);
    fetchEmployees();
  };

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <div>
        <input placeholder="Name" onChange={e => setNewEmployee({ ...newEmployee, name: e.target.value })} />
        <input placeholder="Dept" onChange={e => setNewEmployee({ ...newEmployee, department: e.target.value })} />
        <input placeholder="Email" onChange={e => setNewEmployee({ ...newEmployee, email: e.target.value })} />
        <input placeholder="Phone" onChange={e => setNewEmployee({ ...newEmployee, phone: e.target.value })} />
        <input placeholder="Manager" onChange={e => setNewEmployee({ ...newEmployee, reportingManager: e.target.value })} />
        <button onClick={handleCreate}>Add Employee</button>
      </div>
      <ul>
        {employees.map(emp => (
          <li key={emp.id}>
            {emp.name} - {emp.department} - {emp.email}
            <button onClick={() => handleDelete(emp.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminDashboard;
