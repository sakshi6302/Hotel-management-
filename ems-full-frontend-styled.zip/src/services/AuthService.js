
import axios from 'axios';

const API_URL = 'http://localhost:8082';

export const login = async (username, password) => {
  const res = await axios.post(`${API_URL}/auth/login`, { username, password });
  return res.data;
};

export const register = async (username, password, role) => {
  const res = await axios.post(`${API_URL}/auth/register`, { username, password, role });
  return res.data;
};

export const getToken = () => localStorage.getItem('token');

export const getAuthHeader = () => ({
  headers: { Authorization: `Bearer ${getToken()}` },
});
