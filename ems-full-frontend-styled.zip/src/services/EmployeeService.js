
import axios from 'axios';
import { getAuthHeader } from './AuthService';

const API_URL = 'http://localhost:8082/employees';

export const getAllEmployees = () => axios.get(`${API_URL}/getall`, getAuthHeader());

export const createEmployee = (employee) => axios.post(`${API_URL}/create`, employee, getAuthHeader());

export const updateEmployee = (id, employee) => axios.put(`${API_URL}/${id}`, employee, getAuthHeader());

export const deleteEmployee = (id) => axios.delete(`${API_URL}/${id}`, getAuthHeader());

export const getEmployeeProfile = () => axios.get(`${API_URL}/employee/profile`, getAuthHeader());
