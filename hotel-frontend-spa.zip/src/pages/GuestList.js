import React, { useEffect, useState } from 'react';
import { getAllGuests } from '../api/guestApi';

function GuestList() {
  const [guests, setGuests] = useState([]);

  useEffect(() => {
    getAllGuests().then(res => setGuests(res.data));
  }, []);

  return (
    <div>
      <h2>Guest List</h2>
      <ul>
        {guests.map(guest => (
          <li key={guest.id}>{guest.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default GuestList;