import axios from 'axios';
const API = '/guests';

export const getAllGuests = () => axios.get(API);
export const createGuest = (guest) => axios.post(API, guest);