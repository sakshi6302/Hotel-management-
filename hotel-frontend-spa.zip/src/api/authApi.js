import axios from 'axios';
const API = '/auth';

export const login = (credentials) => axios.post(`${API}/login`, credentials);
export const register = (user) => axios.post(`${API}/register`, user);