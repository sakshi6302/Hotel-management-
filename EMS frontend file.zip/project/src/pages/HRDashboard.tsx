import React, { useState, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { getAllEmployees } from '../services/employeeService';
import { Employee } from '../types/Employee';
import EmployeeCard from '../components/EmployeeCard';

const HRDashboard: React.FC = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [departments, setDepartments] = useState<string[]>([]);

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const data = await getAllEmployees();
        setEmployees(data);
        setFilteredEmployees(data);
        
        // Extract unique departments
        const uniqueDepartments = Array.from(new Set(data.map(emp => emp.department)));
        setDepartments(uniqueDepartments);
      } catch (err) {
        setError('Failed to fetch employees');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchEmployees();
  }, []);

  useEffect(() => {
    let result = [...employees];
    
    // Filter by search term
    if (searchTerm) {
      result = result.filter(
        employee => 
          employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
          employee.department.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Filter by department
    if (selectedDepartment) {
      result = result.filter(employee => employee.department === selectedDepartment);
    }
    
    setFilteredEmployees(result);
  }, [searchTerm, selectedDepartment, employees]);

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedDepartment('');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">HR Dashboard</h1>
      
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Search by name, email, or department"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <select
            className="block w-full sm:w-48 px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            value={selectedDepartment}
            onChange={(e) => setSelectedDepartment(e.target.value)}
          >
            <option value="">All Departments</option>
            {departments.map((dept, index) => (
              <option key={index} value={dept}>{dept}</option>
            ))}
          </select>
          
          {(searchTerm || selectedDepartment) && (
            <button
              onClick={clearFilters}
              className="flex items-center text-gray-600 hover:text-gray-900 px-3 py-2 border border-gray-300 rounded-md sm:text-sm transition-colors"
            >
              <X size={16} className="mr-1" /> Clear
            </button>
          )}
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center my-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
        </div>
      ) : error ? (
        <div className="text-red-500 text-center my-12">{error}</div>
      ) : filteredEmployees.length === 0 ? (
        <div className="text-center my-12 py-8 bg-gray-50 rounded-lg border border-gray-200">
          <p className="text-gray-500 text-lg">No employees found</p>
          {(searchTerm || selectedDepartment) && (
            <button
              onClick={clearFilters}
              className="mt-4 text-blue-600 hover:text-blue-800 font-medium"
            >
              Clear filters
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEmployees.map((employee, index) => (
            <EmployeeCard
              key={index}
              employee={employee}
              isAdmin={false}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default HRDashboard;