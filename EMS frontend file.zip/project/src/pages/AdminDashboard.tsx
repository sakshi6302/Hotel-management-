import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import { User, Users, Plus } from 'lucide-react';
import { getAllEmployees } from '../services/employeeService';
import { Employee } from '../types/Employee';
import EmployeeList from './admin/EmployeeList';
import EmployeeCreate from './admin/EmployeeCreate';
import EmployeeEdit from './admin/EmployeeEdit';

const AdminDashboard: React.FC = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const data = await getAllEmployees();
        setEmployees(data);
      } catch (err) {
        setError('Failed to fetch employees');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchEmployees();
  }, []);

  return (
    <div>
      <Routes>
        <Route path="/" element={
          <>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h1 className="text-2xl font-bold text-gray-800 mb-4">Admin Dashboard</h1>
              <p className="text-gray-600 mb-6">Welcome to the Employee Management System. As an admin, you have full access to manage employees.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-blue-50 p-6 rounded-lg border border-blue-100 hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/admin/employees')}>
                  <div className="flex items-start">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <Users className="h-6 w-6 text-blue-600" />
                    </div>
                    <div className="ml-4">
                      <h2 className="text-lg font-semibold text-gray-800">Manage Employees</h2>
                      <p className="text-gray-600 mt-1">View, edit, create, and delete employee records</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-green-50 p-6 rounded-lg border border-green-100 hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/admin/employees/create')}>
                  <div className="flex items-start">
                    <div className="bg-green-100 p-3 rounded-full">
                      <User className="h-6 w-6 text-green-600" />
                    </div>
                    <div className="ml-4">
                      <h2 className="text-lg font-semibold text-gray-800">Add New Employee</h2>
                      <p className="text-gray-600 mt-1">Create a new employee record in the system</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {isLoading ? (
                <div className="flex justify-center mt-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
                </div>
              ) : error ? (
                <div className="text-red-500 mt-8 text-center">{error}</div>
              ) : (
                <div className="mt-8">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-gray-800">Recent Employees</h2>
                    <button 
                      onClick={() => navigate('/admin/employees')}
                      className="text-blue-600 hover:text-blue-800 flex items-center text-sm"
                    >
                      View All
                    </button>
                  </div>
                  
                  <div className="overflow-x-auto bg-white rounded-lg shadow">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Department</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {employees.slice(0, 5).map((employee, index) => (
                          <tr key={index} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{employee.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{employee.department}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{employee.email}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{employee.phone}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </>
        } />
        <Route path="/employees" element={<EmployeeList />} />
        <Route path="/employees/create" element={<EmployeeCreate />} />
        <Route path="/employees/edit/:id" element={<EmployeeEdit />} />
      </Routes>
    </div>
  );
};

export default AdminDashboard;