import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { getAllEmployees, updateEmployee } from '../../services/employeeService';
import { Employee } from '../../types/Employee';
import EmployeeForm from '../../components/EmployeeForm';

const EmployeeEdit: React.FC = () => {
  const [employee, setEmployee] = useState<Employee | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();

  useEffect(() => {
    const fetchEmployee = async () => {
      try {
        const employees = await getAllEmployees();
        const employee = employees.find(emp => emp.id === Number(id));
        
        if (employee) {
          setEmployee(employee);
        } else {
          setError('Employee not found');
        }
      } catch (err) {
        setError('Failed to fetch employee details');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchEmployee();
  }, [id]);

  const handleSubmit = async (updatedEmployee: Employee) => {
    try {
      setIsLoading(true);
      setError(null);
      await updateEmployee(Number(id), updatedEmployee);
      navigate('/admin/employees');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to update employee');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    navigate('/admin/employees');
  };

  if (isLoading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !employee) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
          <div className="flex">
            <div>
              <p className="text-sm text-red-700">{error || 'Employee not found'}</p>
            </div>
          </div>
        </div>
        <button
          onClick={() => navigate('/admin/employees')}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors"
        >
          Back to Employees
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <button
        onClick={() => navigate('/admin/employees')}
        className="flex items-center text-blue-600 hover:text-blue-800 mb-6 transition-colors"
      >
        <ArrowLeft size={18} className="mr-2" /> Back to Employees
      </button>
      
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Edit Employee</h1>
      
      <EmployeeForm employee={employee} onSubmit={handleSubmit} onCancel={handleCancel} />
    </div>
  );
};

export default EmployeeEdit;