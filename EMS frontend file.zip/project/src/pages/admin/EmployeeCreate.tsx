import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { createEmployee } from '../../services/employeeService';
import { Employee } from '../../types/Employee';
import EmployeeForm from '../../components/EmployeeForm';

const EmployeeCreate: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleSubmit = async (employee: Employee) => {
    try {
      setIsLoading(true);
      setError(null);
      await createEmployee(employee);
      navigate('/admin/employees');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to create employee');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    navigate('/admin/employees');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <button
        onClick={() => navigate('/admin/employees')}
        className="flex items-center text-blue-600 hover:text-blue-800 mb-6 transition-colors"
      >
        <ArrowLeft size={18} className="mr-2" /> Back to Employees
      </button>
      
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Add New Employee</h1>
      
      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
          <div className="flex">
            <div>
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      {isLoading ? (
        <div className="flex justify-center my-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <EmployeeForm onSubmit={handleSubmit} onCancel={handleCancel} />
      )}
    </div>
  );
};

export default EmployeeCreate;