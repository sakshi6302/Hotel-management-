import api from './api';
import { Employee } from '../types/Employee';

export const getAllEmployees = async (): Promise<Employee[]> => {
  const response = await api.get('/employees/getall');
  return response.data;
};

export const createEmployee = async (employee: Employee): Promise<Employee> => {
  const response = await api.post('/employees/create', employee);
  return response.data;
};

export const updateEmployee = async (id: number, employee: Employee): Promise<Employee> => {
  const response = await api.put(`/employees/${id}`, employee);
  return response.data;
};

export const deleteEmployee = async (id: number): Promise<void> => {
  await api.delete(`/employees/${id}`);
};

export const getEmployeeProfile = async (): Promise<Employee[]> => {
  const response = await api.get('/employees/employee/profile');
  return response.data;
};