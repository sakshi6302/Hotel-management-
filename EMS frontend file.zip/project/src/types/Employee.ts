export interface Employee {
  id?: number;
  name: string;
  department: string;
  email: string;
  phone: string;
  reportingManager: string;
}