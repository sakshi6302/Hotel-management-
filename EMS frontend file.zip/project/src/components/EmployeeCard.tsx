import React from 'react';
import { Employee } from '../types/Employee';
import { Pencil, Trash2, Phone, Mail, Building, User } from 'lucide-react';

interface EmployeeCardProps {
  employee: Employee;
  onEdit?: (employee: Employee) => void;
  onDelete?: (id: number) => void;
  isAdmin?: boolean;
}

const EmployeeCard: React.FC<EmployeeCardProps> = ({ 
  employee, 
  onEdit, 
  onDelete, 
  isAdmin = false 
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:shadow-lg transform hover:-translate-y-1">
      <div className="p-6">
        <div className="flex justify-between items-start">
          <h3 className="text-xl font-semibold text-gray-800 mb-2">{employee.name}</h3>
          
          {isAdmin && (
            <div className="flex space-x-2">
              <button 
                onClick={() => onEdit && onEdit(employee)}
                className="text-blue-500 hover:text-blue-700 transition-colors"
                aria-label="Edit employee"
              >
                <Pencil size={18} />
              </button>
              <button 
                onClick={() => onDelete && employee.id && onDelete(employee.id)}
                className="text-red-500 hover:text-red-700 transition-colors"
                aria-label="Delete employee"
              >
                <Trash2 size={18} />
              </button>
            </div>
          )}
        </div>
        
        <div className="mt-4 space-y-2">
          <div className="flex items-center text-gray-600">
            <Building size={16} className="mr-2" />
            <span>{employee.department}</span>
          </div>
          
          <div className="flex items-center text-gray-600">
            <Mail size={16} className="mr-2" />
            <a href={`mailto:${employee.email}`} className="hover:text-blue-600 transition-colors">
              {employee.email}
            </a>
          </div>
          
          <div className="flex items-center text-gray-600">
            <Phone size={16} className="mr-2" />
            <a href={`tel:${employee.phone}`} className="hover:text-blue-600 transition-colors">
              {employee.phone}
            </a>
          </div>
          
          <div className="flex items-center text-gray-600">
            <User size={16} className="mr-2" />
            <span>Reports to: {employee.reportingManager}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeCard;