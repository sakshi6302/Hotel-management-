import React, { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

interface ProtectedRouteProps {
  children: ReactNode;
  roles: string[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, roles }) => {
  const { user, isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Check if user has required role
  const hasRequiredRole = user && roles.some(role => user.roles.includes(role));
  
  if (!hasRequiredRole) {
    // Redirect based on user role
    if (user?.roles.includes('ROLE_ADMIN')) {
      return <Navigate to="/admin" replace />;
    } else if (user?.roles.includes('ROLE_HR')) {
      return <Navigate to="/hr" replace />;
    } else if (user?.roles.includes('ROLE_EMPLOYEE')) {
      return <Navigate to="/employee" replace />;
    } else {
      return <Navigate to="/login" replace />;
    }
  }

  return <>{children}</>;
};

export default ProtectedRoute;