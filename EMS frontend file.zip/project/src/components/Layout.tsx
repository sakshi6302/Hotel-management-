import React from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { LogOut, Menu, X } from 'lucide-react';

const Layout: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user) {
    return <Outlet />;
  }

  const isAdmin = user.roles.includes('ROLE_ADMIN');
  const isHR = user.roles.includes('ROLE_HR');
  const isEmployee = user.roles.includes('ROLE_EMPLOYEE');

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-blue-700">Employee Management System</h1>
            </div>
            
            <div className="hidden md:flex items-center">
              <div className="ml-4 flex items-center md:ml-6">
                <p className="text-sm mr-4">Welcome, {user.username}</p>
                <button
                  onClick={handleLogout}
                  className="flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
                >
                  <LogOut size={18} className="mr-1" /> Logout
                </button>
              </div>
            </div>
            
            <div className="md:hidden flex items-center">
              <button
                onClick={toggleMobileMenu}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-600 hover:text-blue-600 hover:bg-gray-100 focus:outline-none"
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <div className="pt-2 pb-3 space-y-1 border-t">
              <p className="block px-4 py-2 text-sm text-gray-700">Welcome, {user.username}</p>
              <button
                onClick={handleLogout}
                className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                <LogOut size={18} className="mr-2" /> Logout
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Sidebar and content */}
      <div className="flex flex-col md:flex-row">
        {/* Sidebar for larger screens */}
        <div className="hidden md:block w-64 bg-white shadow-sm">
          <nav className="mt-5 px-2">
            <div className="space-y-1">
              {isAdmin && (
                <>
                  <a 
                    href="/admin" 
                    className="group flex items-center px-2 py-2 text-sm leading-5 font-medium text-gray-900 rounded-md hover:text-blue-600 hover:bg-gray-50"
                  >
                    Dashboard
                  </a>
                  <a 
                    href="/admin/employees" 
                    className="group flex items-center px-2 py-2 text-sm leading-5 font-medium text-gray-900 rounded-md hover:text-blue-600 hover:bg-gray-50"
                  >
                    Manage Employees
                  </a>
                </>
              )}
              
              {isHR && (
                <a 
                  href="/hr" 
                  className="group flex items-center px-2 py-2 text-sm leading-5 font-medium text-gray-900 rounded-md hover:text-blue-600 hover:bg-gray-50"
                >
                  View Employees
                </a>
              )}
              
              {isEmployee && (
                <a 
                  href="/employee" 
                  className="group flex items-center px-2 py-2 text-sm leading-5 font-medium text-gray-900 rounded-md hover:text-blue-600 hover:bg-gray-50"
                >
                  My Profile
                </a>
              )}
            </div>
          </nav>
        </div>

        {/* Main content */}
        <main className="flex-1 p-4">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;