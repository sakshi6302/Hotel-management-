import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const EmployeeList = () => {
  const [employees, setEmployees] = useState([]);
  const { auth } = useContext(AuthContext);

  useEffect(() => {
    const fetchData = async () => {
      const res = await axios.get('http://localhost:8080/employees/getall', {
        headers: { Authorization: `Bearer ${auth.token}` },
      });
      setEmployees(res.data);
    };
    fetchData();
  }, [auth.token]);

  return (
    <div>
      <h2>Employees</h2>
      <ul>
        {employees.map(emp => (
          <li key={emp.id}>{emp.name} - {emp.department}</li>
        ))}
      </ul>
    </div>
  );
};

export default EmployeeList;
